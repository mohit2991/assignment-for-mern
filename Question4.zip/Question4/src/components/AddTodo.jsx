import React, { useState } from "react";
import useApi from "../api/useApi";

const AddTodo = ({ addNewTodo }) => {
  const [todo, setTodo] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      id: Math.floor(Math.random() * 1000000) + Date.now(),
      todo,
      completed: false,
      userId: 25,
    };

    try {
      // await useApi.AddTodo(payload);

      addNewTodo(payload);
      setTodo("");
    } catch (error) {
      console.error("Error adding todo:", error);
    }
  };

  return (
    <form
      className="d-flex justify-content-center align-items-center mb-4"
      onSubmit={handleSubmit}
    >
      <input
        type="text"
        value={todo}
        onChange={(e) => setTodo(e.target.value)}
        placeholder="Add a new task"
        className="form-control"
      />
      &nbsp;&nbsp;
      <button
        type="submit"
        className="btn btn-info ms-2"
        disabled={todo === "" ? true : false}
      >
        Add
      </button>
    </form>
  );
};

export default AddTodo;
