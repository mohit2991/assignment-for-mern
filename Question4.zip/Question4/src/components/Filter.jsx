import React from "react";

const Filter = ({ filter, setFilter }) => {
  return (
    <ul className="nav nav-tabs mb-4 pb-2">
      <h4>Filter</h4>
      <li className="ms-2">
        <button
          className="btn btn-info"
          onClick={() => setFilter("all")}
          style={{ color: filter === "all" ? "red" : "" }}
        >
          All
        </button>
      </li>
      <li className="ms-2">
        <button
          className="btn btn-info"
          onClick={() => setFilter("completed")}
          style={{ color: filter === "completed" ? "red" : "" }}
        >
          Completed
        </button>
      </li>
      <li className="ms-2">
        <button
          className="btn btn-info"
          onClick={() => setFilter("pending")}
          style={{ color: filter === "pending" ? "red" : "" }}
        >
          Pending
        </button>
      </li>
    </ul>
  );
};

export default Filter;
