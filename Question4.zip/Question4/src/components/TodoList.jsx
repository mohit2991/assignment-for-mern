import React from "react";
import TodoItem from "./TodoItem";

const TodoList = ({ todos, toggleTodo, deleteTodo }) => {
  return (
    todos?.length > 0 && (
      <table className="table">
        <thead>
          <tr>
            <th>Todo item</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {todos?.map((todo) => (
            <TodoItem
              key={todo.id}
              item={todo}
              toggleTodo={toggleTodo}
              deleteTodo={deleteTodo}
            />
          ))}
        </tbody>
      </table>
    )
  );
};

export default TodoList;
