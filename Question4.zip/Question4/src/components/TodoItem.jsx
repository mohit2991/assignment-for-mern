import React from "react";

const TodoItem = ({ item, toggleTodo, deleteTodo }) => {
  return (
    <tr>
      <td>{item.todo}</td>
      <td>
        <button onClick={() => toggleTodo(item.id)}>
          {item.completed ? "Completed" : "Pending"}
        </button>
      </td>
      <td>
        <button onClick={() => deleteTodo(item.id)}>Delete</button>
      </td>
    </tr>
  );
};

export default TodoItem;
