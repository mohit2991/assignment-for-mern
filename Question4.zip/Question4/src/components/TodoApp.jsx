import React, { useState, useEffect } from "react";
import TodoList from "./TodoList";
import AddTodo from "./AddTodo";
import Filter from "./Filter";
// import useApi from "../api/useApi";

const TodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState("all");

  // const getTodos = async () => {
  //   const data = await useApi.Todos(25);
  //   setTodos(data.todos);
  // };

  useEffect(() => {
    // getTodos();

    const todosData = localStorage.getItem("todos");

    if (todosData !== null) {
      setTodos(JSON.parse(todosData));
    }
  }, []);

  const addNewTodo = (task) => {
    localStorage.setItem("todos", JSON.stringify([...todos, task]));

    setTodos([...todos, task]);
  };

  const toggleTodo = (id) => {
    const updatedTodos = todos.map((todo) =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    );

    setTodos(updatedTodos);

    localStorage.setItem("todos", JSON.stringify(updatedTodos));
  };

  const deleteTodo = async (id) => {
    // Use filter to remove the todo with the matching id
    const updatedTodos = todos.filter((todo) => todo.id !== id);

    // Update the state with the new list of todos
    setTodos(updatedTodos);

    // Update localStorage with the new list
    localStorage.setItem("todos", JSON.stringify(updatedTodos));
  };

  const filteredTodos =
    todos?.length > 0
      ? todos?.filter((todo) => {
          if (filter === "completed") return todo.completed;
          if (filter === "pending") return !todo.completed;
          return true;
        })
      : [];

  return (
    <section className="vh-100 gradient-custom">
      <div className="container mt-4">
        <div className="row d-flex justify-content-center align-items-center h-100">
          <div className="col col-xl-10">
            <div className="card">
              <div className="card-body p-5">
                <h1 className="text-center mb-4">Todo List</h1>
                <AddTodo addNewTodo={addNewTodo} />
                <Filter filter={filter} setFilter={setFilter} />
                <TodoList
                  todos={filteredTodos}
                  toggleTodo={toggleTodo}
                  deleteTodo={deleteTodo}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TodoApp;
