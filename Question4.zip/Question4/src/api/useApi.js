import api from './api';
import endpoint from "./endPoint";

const useApi = {
    Todos: async (userId) => {
        const url = `${endpoint.todos}`;
        return await api(url, 'GET')
    },
    AddTodo: async (payload) => {
        return await api(endpoint.addTodo, 'POST', payload)
    },
    UpdateTodoStatus: async (id, payload) => {
        const url = `${endpoint.updatTodo}/${id}`;
        return await api(url, 'PUT', payload);
    },
    deleteTodo: async (id) => {
        const url = `${endpoint.deleteTodo}/${id}`;
        return await api(url, 'DELETE');
    },
}

export default useApi;