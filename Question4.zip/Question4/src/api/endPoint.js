const endpoint = {
  todos: "todos",
  todosByUser: "todos/user", // By user specific
  addTodo: "todos/add",
  updateTodo: "todos",
  deleteTodo: "todos",
};

export default endpoint;
