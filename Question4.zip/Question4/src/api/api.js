const api = async (url, method = "GET", payload = null) => {
  try {
    const endPoint = `https://dummyjson.com/${url}`;

    const options = {
      method: method,
      headers: {
        "Content-Type": "application/json",
      },
    };

    // Only include body if the method is not GET
    if (method !== "GET" || (method !== "DELETE" && payload)) {
      options.body = JSON.stringify(payload);
    }

    const response = await fetch(endPoint, options);

    if (!response.ok) {
      throw new Error(`Error: ${response.statusText}`);
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("API error:", error);
    throw error;
  }
};

export default api;
